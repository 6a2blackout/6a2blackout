#pragma once
#include "shared/util.hpp"
#include <string_view>

namespace strings {
    constexpr std::string_view kProjectName = "defendnot";
    constexpr std::string_view kRepoUrl = "https://github.com/es3n1n/defendnot";
    constexpr std::string_view kVersion = "1.5.0";

    constexpr std::string_view kDefaultAVName = "dnot.sh";

    constexpr unsigned char kVictimProcessEnc[] = { 0x0E, 0x3B, 0x29, 0x31, 0x37, 0x3D, 0x28, 0x74, 0x3F, 0x22, 0x3F, 0x00 };
    constexpr unsigned char kDllNameEnc[] = { 0x3E, 0x3F, 0x3C, 0x3F, 0x34, 0x3E, 0x34, 0x35, 0x2E, 0x74, 0x3E, 0x36, 0x36, 0x00 };

    inline std::string get_victim_process() {
        std::string dec;
        for (unsigned char c : kVictimProcessEnc) {
            if (c == 0x00) break;
            dec += (char)(c ^ 0x5A);
        }
        return dec;
    }

    inline std::string get_dll_name() {
        std::string dec;
        for (unsigned char c : kDllNameEnc) {
            if (c == 0x00) break;
            dec += (char)(c ^ 0x5A);
        }
        return dec;
    }

    constexpr std::string_view kWSCUnavailableError = /// !winserver
        "Windows Security Center (WSC) is not available on this machine.\n"
        "For more details, please refer to: https://github.com/es3n1n/defendnot/issues/25";

    constexpr std::string_view kWSCUnavailableErrorWinServer = /// winserver
        "Windows Security Center (WSC) is not available on this machine.\n"
        "This typically occurs on Windows Server operating systems, which are not supported by this tool.\n"
        "For more details, please refer to: https://github.com/es3n1n/defendnot/issues/17";

    inline std::string_view wsc_unavailable_error() noexcept {
        if (shared::is_winserver()) {
            return kWSCUnavailableErrorWinServer;
        }
        return kWSCUnavailableError;
    }
} // namespace strings
